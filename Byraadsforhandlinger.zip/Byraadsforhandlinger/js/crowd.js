/*function extractToText(strings){
    var $htmlContent, $htmlPattern, $htmlReplace;
    
    // first remove to unnecessary gaps
    $htmlContent = strings.replace(/\n/g,'').replace(/\r/g,'').replace(/\t/g,'').replace(/&nbsp;/g,' ');
    
    $htmlPattern =  [
	    /\<div>(.*?)\<\/div>/ig,
	    /\<br>(.*?)\<br>/ig,
	    /\<br\/>(.*?)\<br\/>/ig,
	    /\<strong>(.*?)\<\/strong>/ig,
	    /\<em>(.*?)\<\/em>/ig
    ];
    
    $htmlReplace = [
	    '<p>$1</p>',
	    '<p>$1</p>',
	    '<p>$1</p>',
	    '<b>$1</b>',
	    '<i>$1</i>'
    ];
    
    // create loop as the number of pattern
    for (var i = 0; i < $htmlPattern.length; i++) {
      $htmlContent = $htmlContent.replace($htmlPattern[i], $htmlReplace[i]);
    }
    
    return $htmlContent;
}*/
			
function findParaParent(textNode){
    var p = false;
    
    currentNode = textNode;
    while (!p){
	currentNode = currentNode.parentNode;
	if (currentNode != null){
	    if (currentNode.nodeName == "P"){
		p = true
		return currentNode
	    }
	}
	else {
	    return null;
	}	
    }
}

function removeSpan(spanNode){
    pElement = spanNode.parentNode;
     
    $(spanNode).before(getTextNodesIn(spanNode)[0].nodeValue);
    
    $(spanNode).remove();
        
    textPrev = false;
    for (var i = 0, len = pElement.childNodes.length; i < len; ++i) {
	curChildNode = pElement.childNodes[i];
	if (curChildNode.nodeType == 3){
	    if (textPrev){
		prevNode = pElement.childNodes[i - 1];
		$(prevNode).before(prevNode.nodeValue + curChildNode.nodeValue);
		$(prevNode).remove();
		$(curChildNode).remove();
		i = i - 1
		len = len - 1
	    }
	    textPrev = true;
	}
	else{
	    textPrev = false;
	}
    }
}
function IECleanup(parentNode){
    textNodePrev = false;
    prevTextNode = null;
    foundOne = false;
    
    for (var i = 0, len = parentNode.contents().length; i < len; ++i){
	curChild = parentNode.contents()[i];
	
	if (curChild.nodeType == 3 && foundOne != true){
	    if (textNodePrev){
		prevTextString = $(prevTextNode).text()
		curTextString = $(curChild).text()
		textString = prevTextString + curTextString
		
		$(prevTextNode).before(textString);
		$(prevTextNode).remove();
		$(curChild).remove();
		
		foundOne = true;
		//alert(textString)
		//alert("IE Fail")
		
	    }
	    textNodePrev = true;
	    prevTextNode = curChild;
	}
	else {
	    textNodePrev = false
	}
    }
}
function markup(highlightType){
    //var selHtml = getSelectionHtml();
    var sel = rangy.getSelection();
    //var sel = window.getSelection();
    
    
    	    
    if(sel != ""){
	parent = $("div.jqte_editor").get(0);
	
	startNode = sel.anchorNode
	endNode = sel.focusNode
	
	var startParent = $(findParaParent(startNode));
	IECleanup(startParent)
	var affectedNodes = []

	inSelection = false
	for (var i = 0, len = startParent.contents().length; i < len; ++i){
	    curChild = startParent.contents()[i];
	    if (curChild == startNode || curChild == startNode.parentNode){
		if (!inSelection){
		    if (i > 0){
			affectedNodes = affectedNodes.concat([startParent.contents()[i - 1]])
		    }
		    else {
			affectedNodes = affectedNodes.concat(["None"])
		    }
		}
		if (startNode != endNode){
		    inSelection = !inSelection
		}
		affectedNodes = affectedNodes.concat([curChild, sel.anchorOffset])
		//alert("start" + curChild + " " + inSelection)    
	    }
	    else if(curChild == endNode || curChild == endNode.parentNode){
		if (!inSelection && i > 0){
		    affectedNodes = affectedNodes.concat([startParent.contents()[i - 1]])
		}
		inSelection = !inSelection
		affectedNodes = affectedNodes.concat([curChild, sel.focusOffset])
		//alert("end" + curChild + " " + inSelection)
	    }
	    else if(inSelection){
		affectedNodes = affectedNodes.concat(curChild, $(curChild).text().length)
		//alert("inside" + curChild + " " + inSelection)
	    }
	}
	
	first = false
	prev = false

	preNode = affectedNodes[0]
	if(preNode != "None"){
		if(preNode.nodeType == 3){
			if ($(preNode).prev()[0] != "undefined"){
				prev = $(preNode).prev()[0]
			}
			textStartOffSet = $(preNode).text().length
		}
		else{
			prev = preNode
			textStartOffSet = 0
		}
	}
	else{
	    textStartOffSet = 0
	}
       
	for (var i = 1, len = affectedNodes.length; i < len; i = i + 2){
	    if (!first){
		if (startNode == endNode){
		    if (sel.anchorOffset > sel.focusOffset){
			textStartOffSet = textStartOffSet + affectedNodes[i + 1] - (sel.anchorOffset - sel.focusOffset)
			textEndOffset = sel.anchorOffset - sel.focusOffset
		    }
		    else{
			textStartOffSet = textStartOffSet + affectedNodes[i + 1]
			textEndOffset = sel.focusOffset - sel.anchorOffset
		    }
		}
		else{
		    textStartOffSet = textStartOffSet + affectedNodes[i + 1]
		    textEndOffset = $(affectedNodes[i]).text().substr(affectedNodes[i + 1]).length
		}
		first = !first
	    } else {
		//is Last
		if (i + 2 == len){
		    textEndOffset = textEndOffset + affectedNodes[i + 1]
		}
		else {
		    textEndOffset = textEndOffset + affectedNodes[i + 1]
		}
	    }
	    if(affectedNodes[i].nodeName == "SPAN"){
		removeSpan(affectedNodes[i])
	    }
	    
	}
	
	if (prev){
	    for (var i = 0, len = startParent.contents().length; i < len; ++i){
		curChild = startParent.contents()[i];
		if (prev == curChild){
		    textNode = $(startParent.contents()[i + 1])
		}
	    }
	}
	else {
	    textNode = $($(startParent).contents()[0])
	}
	
	if (highlightType != "X"){
	    //alert(textStartOffSet + " | " + textEndOffset)
	    var before = textNode.text().substr(0, textStartOffSet);
	    var target = textNode.text().substr(textStartOffSet, textEndOffset)
	    var after = textNode.text().substr(textStartOffSet + textEndOffset)
	    
	    if (target.substr(target.length-1) == " "){
		target = target.substr(0, target.length - 1);
		after = " " + after;
	    }

	    
	    $(textNode).before(before)
	    var newNode=document.createElement("span");
	    newNode.innerHTML=target;
	    newNode.setAttribute("id", highlightType);
	    
	    $(textNode).before(newNode)
	    $(textNode).before(after)
	    $(textNode).remove()
	    
	    selectElementContents(newNode)
	};
    };
}

$( document ).ready(function() {
    $( "button.markup" ).click(function( event ) {
	var button_id = $(event.currentTarget).attr('id');
	markup(button_id);
    });
});

function setSelectionRange(element, start, end) {
    var rng = document.createRange(),
        sel = getSelection(),
        n, o = 0,
        tw = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null, null);
    while (n = tw.nextNode()) {
        o += n.nodeValue.length;
        if (o > start) {
            rng.setStart(n, n.nodeValue.length + start - o);
            start = Infinity;
        }
        if (o >= end) {
            rng.setEnd(n, n.nodeValue.length + end - o);
            break;
        }
    }
    sel.removeAllRanges();
    sel.addRange(rng);
};

function setCaret(element, index) {
    setSelectionRange(element, index, index);
};

function getTextNodesIn(node, includeWhitespaceNodes) {
    var textNodes = [], whitespace = /^\s*$/;

    function getTextNodes(node) {
        if (node.nodeType == 3) {
            if (includeWhitespaceNodes || !whitespace.test(node.nodeValue)) {
                textNodes.push(node);
            }
        } else {
            for (var i = 0, len = node.childNodes.length; i < len; ++i) {
                getTextNodes(node.childNodes[i]);
            }
        }
    }

    getTextNodes(node);
    return textNodes;
}
function selectElementContents(el) {
    if (window.getSelection && document.createRange) {
        var sel = window.getSelection();
        var range = document.createRange();
        range.selectNodeContents(el);
        sel.removeAllRanges();
        sel.addRange(range);
    } else if (document.selection && document.body.createTextRange) {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(el);
        textRange.select();
    }
}
function getSelectionHtml() {
    var html = "";
    if (typeof window.getSelection != "undefined") {
        var sel = window.getSelection();
        if (sel.rangeCount) {
            var container = document.createElement("div");
            for (var i = 0, len = sel.rangeCount; i < len; ++i) {
                container.appendChild(sel.getRangeAt(i).cloneContents());
            }
            html = container.innerHTML;
        }
    } else if (typeof document.selection != "undefined") {
        if (document.selection.type == "Text") {
            html = document.selection.createRange().htmlText;
        }
    }
    return html;
}