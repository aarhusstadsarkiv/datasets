# -*- coding: UTF-8 -*-
def mapTemplateToPage(page, htmlPlaceholder, htmlBody):
    return page.replace(htmlPlaceholder, htmlBody)

def updateAppForm(page, collectionID, pdfPageNr, dataText):
    ### page is the Html Page
    
    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlPlaceholder = u"<!-- appForm -->"
    
    ###  
    htmlBody = u"""
        <form id='postForm' method='POST' enctype='application/x-www-form-urlencoded' action='/recieveRecord'>
        
        <textarea class="editor" name="textData" style='display:none;'>""" + dataText + u"""</textarea>
        
        <input name="collectionID" type="hidden" value='""" + collectionID + u"""' />
        <input name="page" type="hidden" value='""" + pdfPageNr + u"""' />
        <div id="confirm" class="right">
            <ul style='width: 100%;'>
              <li style='float:left'><button id='delayRecord' type="button" class="btn">Gem side</button></li>
              <li style='float:left; padding-right: 4px; margin-left:4px; margin-top:3px;'><input style="width:20px;" id='pageInput'></input></li>
              <li style='float:left'><button id='getPage' type="button" class="btn">Gå til siden</button></li>
              <li style='float:right'><input class="btn btn-primary" type='submit' value='Gem og fortsæt'></li> 
            </ul>
        </div>
        </form>
        
        <script type="text/javascript">$(".editor").jqte({color: false,
                                                          b: false,
                                                          fsize: false,
                                                          i: false,
                                                          link: false,
                                                          ol: false,
                                                          ul: false,
                                                          u: false,
                                                          indent: false,
                                                          outdent: false,
                                                          remove: false,
                                                          right: false,
                                                          center: false,
                                                          left: false,
                                                          sub: false,
                                                          sup: false,
                                                          strike: false,
                                                          rule: false,
                                                          source: false,
                                                          unlink: false});
        </script>
        
        <script type="text/javascript">
            $('button#delayRecord').click(function(){
                $("#postForm").attr("action", "/delayRecord");
                document.getElementById("postForm").submit();
            })
            $('button#getPage').click(function(){
                var page = $('input#pageInput').val();
                if (page != ""){
                    var base = '/markRecord/""" + collectionID + u"""-';
                    document.location.href=base + page;    
                }
            })
        </script>
        """
        
    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)

def updateAppPdf(page, dateID, pageID):
    ### page is the Html Page
    
    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlBody = u"""
        <div id="viewport" style="width:620px;height:755px;overflow:auto;">
            <canvas id="the-canvas"></canvas>
        </div>
        
        <script type="text/javascript" src="../js/pdf.js"></script>
        <script type="text/javascript">

        var pdfDoc = null;
        var url = "../static/""" + dateID + u""".pdf";
        
        pageNum = """ + pageID + """;
        var canvas = document.getElementById('the-canvas');
        var context = canvas.getContext('2d');
        
        var setScale = false;
        var scale = 1
        
        function renderPage(num) {
            // Using promise to fetch the page
            pdfDoc.getPage(num).then(function(page) {
            
            scale = 503.0 / page.getViewport(1).width;
            setScale = true;
            
            //
            // Prepare canvas using PDF page dimensions
            //
            
            var viewport = page.getViewport(scale);
            canvas.height = viewport.height;
            canvas.width = viewport.width;
              
            //
            // Render PDF page into canvas context
            //
            var renderContext = {
              canvasContext: context,
              viewport: viewport
            };
            page.render(renderContext);
            
            // Update page counters
            document.getElementById('page_num').textContent = pageNum;
            document.getElementById('page_count').textContent = pdfDoc.numPages;
            });
        };
        
        function zoomIn(){
            pdfDoc.getPage(pageNum).then(function(page){
                scale = scale + 0.1
                if (scale >= 4){
                    scale = 4;
                }
                
                var viewport = page.getViewport(scale);
                
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                
                var renderContext = {
                    canvasContext: context,
                    viewport: viewport
                };
                page.render(renderContext);
            });
        }
        function zoomOut(){
            pdfDoc.getPage(pageNum).then(function(page){
                scale = scale - 0.1
                if (scale <= 0){
                    scale = 0.1;
                }
                
                var viewport = page.getViewport(scale);
                
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                
                var renderContext = {
                    canvasContext: context,
                    viewport: viewport
                };
                page.render(renderContext);
            });
        }
        
        //
        // Go to previous page
        //
        function goPrevious() {
            if (pageNum <= 1)
                return;
            pageNum--;
            renderPage(pageNum);
        }
        
        //
        // Go to next page
        //
        function goNext() {
            if (pageNum >= pdfDoc.numPages)
                return;
            pageNum++;
            renderPage(pageNum);
        }
        
        var viewport = $("div#viewport");
        viewport.css("width",  "520px");
        viewport.css("height", "625px");
        viewport.css("overflow", "auto");
        viewport.dragscrollable({dragSelector:'#the-canvas'});
        
        //
        // Asynchronously download PDF as an ArrayBuffer
        //
        PDFJS.getDocument(url).then(function(pdf) {
        pdfDoc = pdf;
        renderPage(pageNum);
        });
        </script>
        """
    
    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)

#def updateAppPdf(page, dateID, pageID):
#    ### page is the Html Page
#    
#    ### Placeholder is the tag to find and replace in the page template
#    ### Body is the html container to inject into the placeholder position in the page template
#    htmlPlaceholder = u"<!-- pdf.js -->"
#    htmlBody = u"""
#        <div id="viewport" style="width:620px;height:755px;overflow:auto;">
#            <canvas id="the-canvas" float:left"></canvas>
#        </div>
#        
#        <script type="text/javascript" src="../js/pdf.js"></script>
#        <script type="text/javascript">
#        //
#        // NOTE: 
#        // Modifying the URL below to another server will likely *NOT* work. Because of browser
#        // security restrictions, we have to use a file server with special headers
#        // (CORS) - most servers don't support cross-origin browser requests.
#        //
#        var url = "../static/""" + dateID + u""".pdf";
#        
#        //
#        // Disable workers to avoid yet another cross-origin issue (workers need the URL of
#        // the script to be loaded, and currently do not allow cross-origin scripts)
#        //
#        PDFJS.disableWorker = true;
#        
#        var pdfDoc = null,
#        pageNum = """ + pageID + """,
#        //scale = 1.0,
#        canvas = document.getElementById('the-canvas'),
#        ctx = canvas.getContext('2d');
#        
#        var setScale = false;
#        //
#        // Get page info from document, resize canvas accordingly, and render page
#        //
#        function renderPage(num) {
#        // Using promise to fetch the page
#        pdfDoc.getPage(num).then(function(page) {
#        
#        ///CHECK THIS
#        if (setScale == false){
#            scale = canvas.width / page.getViewport(0.60).width;
#            setScale = true;
#        }
#        
#        var viewport = page.getViewport(scale);
#        
#        canvas.height = viewport.height;
#        canvas.width = viewport.width;
#        
#        // Render PDF page into canvas context
#        var renderContext = {
#            canvasContext: ctx,
#            viewport: viewport
#        };
#        page.render(renderContext);
#        });
#        
#        // Update page counters
#        document.getElementById('page_num').textContent = pageNum;
#        document.getElementById('page_count').textContent = pdfDoc.numPages;
#        }
#        
#        function zoomIn(){
#            pdfDoc.getPage(pageNum).then(function(page){
#                scale = scale + 0.1
#                if (scale >= 2){
#                    scale = 2;
#                }
#                
#                var viewport = page.getViewport(scale + 0.1);
#                
#                canvas.height = viewport.height;
#                canvas.width = viewport.width;
#                
#                var renderContext = {
#                    canvasContext: ctx,
#                    viewport: viewport
#                };
#                page.render(renderContext);
#            });
#        }
#        function zoomOut(){
#            pdfDoc.getPage(pageNum).then(function(page){
#                scale = scale - 0.1
#                if (scale <= 0){
#                    scale = 0.1;
#                }
#                
#                var viewport = page.getViewport(scale + 0.1);
#                
#                canvas.height = viewport.height;
#                canvas.width = viewport.width;
#                
#                var renderContext = {
#                    canvasContext: ctx,
#                    viewport: viewport
#                };
#                page.render(renderContext);
#            });
#        }
#        
#        //
#        // Go to previous page
#        //
#        function goPrevious() {
#        if (pageNum <= 1)
#        return;
#        pageNum--;
#        renderPage(pageNum);
#        }
#        
#        //
#        // Go to next page
#        //
#        function goNext() {
#        if (pageNum >= pdfDoc.numPages)
#        return;
#        pageNum++;
#        renderPage(pageNum);
#        
#        }
#        
#        var viewport = $("div#viewport");
#        viewport.css("width",  "520px");
#        viewport.css("height", "625px");
#        viewport.css("overflow", "auto");
#        viewport.dragscrollable({dragSelector:'#the-canvas'});
#        //
#        // Asynchronously download PDF as an ArrayBuffer
#        //
#        PDFJS.getDocument(url).then(function showPDF(_pdfDoc) {
#        pdfDoc = _pdfDoc;
#        renderPage(pageNum);
#        });
#        </script>"""
#    
#    
#    ### Dont touch! Returned information for the web server :D
#    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)