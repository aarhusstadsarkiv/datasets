from google.appengine.ext import db

class User(db.Model):
	name = db.StringProperty()
	email = db.StringProperty()
	password = db.StringProperty()
	antal = db.IntegerProperty()
	
class Data(db.Model):
	dataID = db.StringProperty()
	textData = db.TextProperty()
	
class RecordCollection(db.Model):
	collectionID = db.StringProperty()
	status = db.StringProperty()
	assUser = db.ReferenceProperty(User)
		
	untouchedRecords = db.StringProperty()
	doneRecords = db.StringProperty()
	
	lastModified = db.DateTimeProperty(indexed=True, auto_now=True)

def unlockRecordCollection(recordCollection):
	recordCollection.assUser = None
	recordCollection.status = "ready"
	recordCollection.put()

@db.transactional	
def lockRecordCollection(recordCollection, user):
	recordCollection.assUser = user
	recordCollection.status = "locked"
	recordCollection.put()

