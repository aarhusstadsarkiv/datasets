# -*- coding: UTF-8 -*-
#!/usr/bin/env python

import webapp2
from webapp2_extras import routes

import cgi
import codecs
import json
import re
import time
import os

from dataStoreStructure import *
from basicTemplates import *
from markupTemplates import *

if (os.getenv('SERVER_SOFTWARE') and os.getenv('SERVER_SOFTWARE').startswith('Google App Engine/')):
    ALLOWED_SCHEMES = ['https']
else:
    ALLOWED_SCHEMES = ['http']

TOKEN = "aar-dev"

def commaStringToArray(commaString):
        if commaString:
            if commaString != "":
                array = commaString.split(",")
            else:
                array = []
                
            return array
        else:
           return [] 
        
def arrayToCommaString(array):
    sortedArray = sorted(array, key=lambda e: int(e))
    
    string = u""
        
    for entity in sortedArray:
        string = string + entity + ","
        
    return string[:len(string)-1]

## Cookie Control login feature
def setCookie(self, args, cookieDuration = 28800):
    for element in args:
        self.response.set_cookie(element, args.get(element), max_age = cookieDuration)

def deleteCookie(self, args):
    for element in args:
        self.response.delete_cookie(element)

class CrowdServer(webapp2.RequestHandler):
    #####################
    ### Login Session ###
    #####################
    def sessionHandler(self):
        userName = self.request.cookies.get("userName")
        
        sessionDict = dict()
        
        if userName != None:
            cookieDict = dict()
            cookieDict["userName"] = userName
            
            setCookie(self, cookieDict)
            
            ##userName, Access Level
            sessionDict["userName"] = userName
            if userName == "stadsarkiv@aarhus.dk":
                sessionDict["accessLevel"] = 2
            else:
                sessionDict["accessLevel"] = 1
            
            return sessionDict
        else:
            sessionDict["userName"] = "guest"
            sessionDict["accessLevel"] = 0
            
            return sessionDict
            
    def sessionCheck(self, accessLevel, defaultAccessRequered):
        if accessLevel >= defaultAccessRequered:
            return True
        else:
            return False
        
    #######################
    ### Server Handlers ###
    #######################
    def basicPipeline(self, first, second, postDict=None):
        session = self.sessionHandler()
        
        urlHandlerDict = self.urlHandler(first, second, session, postDict)
        self.deployTemplate(urlHandlerDict)
    
    def get(self, first = None, second = None):
        self.basicPipeline(first, second)
        
    def post(self, first = None, second = None):
        def postDictSet(formlabel, pType = 'string'):
            entity = self.request.get(formlabel, default_value=None)
            if entity != None:
                if pType == 'string':
                    entity = cgi.escape(entity)
                elif pType == 'int':
                    try:
                        entity = int(entity)
                    except:
                        entity = None
                    
            postDict[formlabel]=entity
    
        intFlag = 'int'
                
        postDict = dict()
        
        if first == "recieveRecord":
            postDictSet("textData")
            postDictSet("collectionID")
            postDictSet("page")
        elif first == "delayRecord":
            postDictSet("textData")
            postDictSet("collectionID")
            postDictSet("page") 
        elif first == "login":
            postDictSet("email")
            postDictSet("password")
        
        self.basicPipeline(first, second, postDict)
    
    def setupApp(self, path):
        config = codecs.open(path, encoding="utf-8").read()
        setupDict = json.loads(config)
        
        return setupDict
    
    def urlHandler(self, first, second, session, postDict):
        def callType(postDict):
            if postDict == None:
                return "Get"
            else:
                return "Post"
        
        ###################
        ### BASIC SETUP ###
        ###################
        urlHandlerDict = dict()
        urlHandlerDict["page"] = "Siden kunne ikke findes."
        urlHandlerDict["urlLevel"] = 0
        
        #########################
        ### SESSION USER DATA ###
        #########################
        userName = session.get("userName")
        accessLevel = session.get("accessLevel")
        
        urlHandlerDict["userName"] = userName
        urlHandlerDict["accessLevel"] = accessLevel
        
        ## APP SETUP DATA
        #setupDict = self.setupApp("templates//config.json")
        urlHandlerDict["setupDict"] = ""#setupDict
        
        
        dbHandler = StadsarkivCrowdDBHandler()
        
        if first == None or first == "delayed" or first == "done" or first=="noRecordsLeft" or first=="quota":
            if self.sessionCheck(accessLevel, 1):
                page = webtemplate("templates//minSide")
                
                user = dbHandler.getUser(userName)
                userRecordList = dbHandler.getActiveRecordCollections(user)
                
                page = updateMinSideRecords(page, userRecordList)
                page = updateMinSideUserInfo(page, user)
                if first == "delayed":
                    text = u"""Mødet er gemt og sat på pause."""
                    page = updateTextField(page, text)
                elif first == "done":
                    text = u"""Du er færdig med mødet! Hent et nyt møde eller arbejd videre med et eksisterende."""
                    page = updateTextField(page, text, "alert alert-success")
                elif first == "noRecordsLeft":
                    text = u"""Der er ikke flere møder tilgængelige på nuværende tidspunkt."""
                    page = updateTextField(page, text, "alert alert-error")
                elif first == "quota":
                    text = u"""Du må samlet maksimalt arbejde med 5 samtidige møder."""
                    page = updateTextField(page, text)
                
                urlHandlerDict["page"] = page
            else:
                page = webtemplate("templates//index")
                #page = updateIndex(page)
                
                urlHandlerDict["page"] = page
        
        elif first == "top20":
            page = webtemplate("templates//top20")
            top20List = dbHandler.getTop20List()
            
            if top20List:
                page = updateTop20(page, top20List)
                
            urlHandlerDict["page"] = page
                
        elif first == "getNewRecord":
            if self.sessionCheck(accessLevel, 1):
                user = dbHandler.getUser(userName)
                
                size = len(dbHandler.getActiveRecordCollections(user))
                if size < 5:        
                    newRecordCollection = dbHandler.getReadyRecordCollection(user)
                    
                    if newRecordCollection:
                        recordCollectionID = newRecordCollection.collectionID
                        untouchedRecords = newRecordCollection.untouchedRecords
                        if untouchedRecords.find(",") == -1 and untouchedRecords != "":
                                currentRecord = 1
                        else:
                                currentRecord = untouchedRecords[:untouchedRecords.find(",")]
                        
                        url = "markRecord/{0}-{1}".format(recordCollectionID, currentRecord)
                        self.redirect(url)
                    else:
                        self.redirect("/noRecordsLeft")
                else:
                    self.redirect("/quota")
            else:
                self.redirect("/")
            
        elif first == "markRecord":
            if self.sessionCheck(accessLevel, 1):
                user = dbHandler.getUser(userName)
            
                if second:
                    page = webtemplate("templates//appTemplate")
                    
                    collectionID, pageID = re.split("-", second)
                
                    page = updateAppPdf(page, collectionID, pageID)
                    dataEntity = dbHandler.getData(second)
                    if dataEntity:
                        page = updateAppForm(page, collectionID, pageID, dataEntity.textData)
                        urlHandlerDict["page"] = page
                    else:
                        urlHandlerDict["page"] = "Siden Findes ikke"
                else:
                    urlHandlerDict["page"] = "Fejl"
            else:
                self.redirect("/")
        
        elif first == "recieveRecord":
            if self.sessionCheck(accessLevel, 1):
                ##update Record
                page = postDict.get("page")
                textData = postDict.get("textData")
                collectionID = postDict.get("collectionID")
                dataID = collectionID + "-" + page
                
                dbHandler.updateData(dataID, textData)
                status, ID, nextPage = dbHandler.updateRecordCollection(collectionID, page)

                if status == "locked":
                    self.redirect("/markRecord/{0}-{1}".format(ID, nextPage))
                else:
                    self.redirect("/done")
            else:
                self.redirect("/")
            
        elif first == "delayRecord":
            if self.sessionCheck(accessLevel, 1):
                page = postDict.get("page")
                textData = postDict.get("textData").rstrip()
                collectionID = postDict.get("collectionID")
                dataID = collectionID + "-" + page
                
                dbHandler.updateData(dataID, textData)
                
                time.sleep(0.5)
                self.redirect("/delayed")
            else:
                self.redirect("/")
            
        elif first == "login":
            if "Post" == callType(postDict):
                validUser = dbHandler.authUser(postDict.get("email").lower(), postDict.get("password"))
                
                #self.bPrint(validUser)
                if validUser:
                    cookieDict = dict()
                    cookieDict["userName"] = validUser.email
                    setCookie(self, cookieDict)
                    
                    self.redirect("/")
                else:
                    #Try again
                    page = webtemplate("templates//login")
                    page = updateTextField(page, u"Email eller kodeord er forkert! Prøv igen.")
                    page = updateLogin(page)
                    
                    urlHandlerDict["page"] = page
            else:
                page = webtemplate("templates//login")
                page = updateLogin(page)
                
                urlHandlerDict["page"] = page
            
        elif first == "logout":
            if self.sessionCheck(accessLevel, 1):
                #User logout
                cookieDict = dict()
                cookieDict["userName"] = None
                deleteCookie(self, cookieDict)
                self.redirect("/")
            else:
                #Visitor is not logged in
                self.redirect("/")
        
        elif first == "tutorial":
            page = webtemplate("templates//tutorial")
            urlHandlerDict["page"] = page
            
        return urlHandlerDict
    
    def bPrint(self, value):
        self.response.out.write(value)
    def deployTemplate(self, urlHandlerDict):
        ##Pipeline method
        page = urlHandlerDict.get("page")
        urlLevel = urlHandlerDict.get("urlLevel")
        accessLevel = urlHandlerDict.get("accessLevel")
        setupDict = urlHandlerDict.get("setupDict")
        
        page = updateMetaHeader(page)
        page = updateTopNav(page, accessLevel)
        page = updateFooter(page)
        
        ## Cache
        #self.response.cache_control = 'public'
        #self.response.cache_control.max_age = 300
        ##
        self.response.out.write(page)

class StadsarkivCrowdDBHandler:
    def selectFromQuery(self, returnQuery, more=False):
        result = False
        
        if more:
            resultList = []
            for entity in returnQuery:
                resultList.append(entity)
            
            if len(resultList) > 0:
                result = resultList
        else:    
            for entity in returnQuery:
                result = entity
        
        return result
    
    ## getUser
    def getUser(self, email):
        gqlString = u"SELECT * FROM User WHERE email='{0}'".format(email)
        returnQuery = db.GqlQuery(gqlString)
        
        return self.selectFromQuery(returnQuery)
    
    def authUser(self, email, password):
        gqlString = u"SELECT * FROM User WHERE email='{0}' AND password='{1}'".format(email, password)
        
        returnQuery = db.GqlQuery(gqlString)
        
        return self.selectFromQuery(returnQuery)
    
    def isAllowed_User_Record(self, user, recordCollectionID):
        if True:
            return True
        else:
            return False
    
    def getTop20List(self):
        gqlString = u"SELECT * FROM User WHERE antal>0 ORDER BY antal DESC LIMIT 20"
        
        returnQuery = db.GqlQuery(gqlString)
        
        return self.selectFromQuery(returnQuery, True)    
    
    ## Record Collections
    def getRecordCollection(self, collectionID):
        gqlString = u"SELECT * FROM RecordCollection WHERE collectionID='{0}'".format(collectionID)
        returnQuery = db.GqlQuery(gqlString)
        
        return self.selectFromQuery(returnQuery)
    
    def getReadyRecordCollection(self, user):
        gqlString = u"SELECT * FROM RecordCollection WHERE status='ready'"
        
        returnQuery = db.GqlQuery(gqlString)
        
        sortedByOldestQuery = sorted(returnQuery, key=lambda e: e.collectionID, reverse=True)
        result = False
        
        for entity in sortedByOldestQuery:
            result = entity
        
        if result:
            lockRecordCollection(result, user)
            
        return result
    
    def getActiveRecordCollections(self, user):
        gqlString = u"SELECT * FROM RecordCollection WHERE assUser=:1 AND status='locked'"
        
        returnQuery = db.GqlQuery(gqlString, user)
        
        lockedList = self.selectFromQuery(returnQuery, True)
        
        gqlString = u"SELECT * FROM RecordCollection WHERE assUser=:1 AND status='delayed'"
        
        returnQuery = db.GqlQuery(gqlString, user)
        
        delayedList = self.selectFromQuery(returnQuery, True)
        
        returnedList = []
        if lockedList:
            for entity in lockedList:
                returnedList.append(entity)
        if delayedList:
            for entity in delayedList:
                returnedList.append(entity)
        
        return returnedList

    def getPausedRecordCollection(self, user):
        gqlString = u"SELECT * FROM RecordCollection WHERE assUser=:1 AND status='delayed'"
        
        returnQuery = db.GqlQuery(gqlString, user)
        
        return self.selectFromQuery(returnQuery)
    
    def pauseRecordCollection(self, collectionID):
        recordCollection = self.getRecordCollection(collectionID)
        
        recordCollection.status = "delayed"
        recordCollection.put()
        receipt = (recordCollection.status, None, None)
        return receipt
    
    def updateRecordCollection(self, collectionID, page):
        recordCollection = self.getRecordCollection(collectionID)
        
        untouchedPages = commaStringToArray(recordCollection.untouchedRecords)
        donePages = commaStringToArray(recordCollection.doneRecords)
        
        nextPage = None
        if len(untouchedPages) > 0:
            try:
                index = untouchedPages.index(page)
            
                recordUpdated = untouchedPages.pop(index)
                donePages.append(recordUpdated)
            
                recordCollection.untouchedRecords = arrayToCommaString(untouchedPages)
                recordCollection.doneRecords = arrayToCommaString(donePages)
                recordCollection.status = "locked"
                recordCollection.put()
            except:
                pass
            #Done
            if len(untouchedPages) == 0:
                recordCollection.status = "done"
                recordCollection.put()
                
                pages = len(donePages)
                
                assUser = recordCollection.assUser
                if assUser.antal:
                    assUser.antal = assUser.antal + pages
                else:
                    assUser.antal = pages
                    
                assUser.put()
            ##has more pages
            else:
                nextPage = untouchedPages[0]
        else:
            return ("done", recordCollection.collectionID, False)
        
        return (recordCollection.status, recordCollection.collectionID, nextPage)
    
    ## Data Methods
    def getData(self, dataID):
        gqlString = u"SELECT * FROM Data WHERE dataID ='{0}'".format(dataID)
        returnQuery = db.GqlQuery(gqlString)
        
        return self.selectFromQuery(returnQuery)
        
    def updateData(self, dataID, textData):
        data = self.getData(dataID)
        if not data:
            data = Data()
        
        data.dataID = dataID
        data.textData = textData
        
        data.put()

class HackServer(webapp2.RequestHandler):
    def selectFromQuery(self, returnQuery, more=False):
        if more:
            resultList = []
            for entity in returnQuery:
                resultList.append(entity)
            
            return resultList
        else:
            result = False
            for entity in returnQuery:
                result = entity
        
            return result
    
    def getDataHack(self):
        gqlString = u"SELECT * FROM User where antal > 0"
        returnQuery = db.GqlQuery(gqlString)
        
        return self.selectFromQuery(returnQuery, True)
    
    def get(self):
        entryResult = {}
        returnList = []
        
        userList = self.getDataHack()
        
        
        for user in userList:
            userRow = [user.email, user.name, user.password]
            returnList.append(userRow)
            
        entryResult["result"] = returnList
        
        encoded = json.dumps(entryResult, indent=3)
        self.response.headers['Content-Type'] = 'application/json'
        self.response.out.write(encoded)

class DLCrowd(webapp2.RequestHandler):
    ## Record Collections
    def getRecordCollection(self, collectionID):
        gqlString = "SELECT * FROM RecordCollection WHERE collectionID >= '%s' AND collectionID < '%s'" % (collectionID, collectionID + u"\ufffd")
        returnQuery = db.GqlQuery(gqlString)
        
        return self.selectFromQuery(returnQuery, True)
    
    def getDataHack(self, dataString):
        gqlString = u"SELECT * FROM Data WHERE dataID >= '%s' AND dataID < '%s'" % (dataString, dataString + u"\ufffd")
        returnQuery = db.GqlQuery(gqlString)
        
        return self.selectFromQuery(returnQuery, True)
    
    def getData(self, dataID):
        gqlString = u"SELECT * FROM Data WHERE dataID = '%s'" % dataID
        returnQuery = db.GqlQuery(gqlString)
        
        return self.selectFromQuery(returnQuery, True)
    
    def selectFromQuery(self, returnQuery, more=False):
        if more:
            resultList = []
            for entity in returnQuery:
                resultList.append(entity)
            
            return resultList
        else:
            result = False
            for entity in returnQuery:
                result = entity
        
            return result
    
    def get(self):
        parameters = self.request.params
        token = parameters.get("token")
        
        if token == TOKEN:
            yearMonth = parameters.get("entry")
            if yearMonth:
                ##collectionGroup = self.getRecordCollection(yearMonth)
                ##
                entryResult = {}
                returnList = []
                ##
                ##globalBreak = False
                ##for collection in collectionGroup:
                ##    if globalBreak:
                ##        break
                #    
                #    if collection.status == "done":
                #        collectionID = collection.collectionID
                #        pageList = collection.doneRecords
                #        pageList = pageList.split(",")
                #
                pageList = self.getDataHack(yearMonth)
                
                pageDict = {}
                for page in pageList:
                    pageDataDict = {}
                    #pageData = "-".join((collectionID, page))
                    
                    pageData = page.dataID
                    dataList = page.textData
                    #dataList = self.getData(pageData)
                    isAlready = pageDict.get(pageData, None)
                    
                    
                    if isAlready == None:
                        textData = dataList                        
                        pageDataDict["page_id"] = pageData
                        pageDataDict["text_data"] = textData
                        pageDict[pageData] = True
                    else:
                        oldEntry = returnList.pop()
                        oldValue = oldEntry.get("text_data")
                        
                        if len(oldValue) < dataList:
                            finalValue = dataList
                        else:
                            finalValue = oldValue
                        
                        oldEntry["text_data"] = finalValue
                        
                        pageDataDict = oldEntry
                        #self.response.out.write("multible entires for this page: %s" % pageData)
                        #globalBreak = True
                        #break
                
                    returnList.append(pageDataDict)
                    #else:
                    #    self.response.out.write("still unfinished items in this collection %s" % collection.collectionID)
                    #    globalBreak = True
                
                entryResult["result"] = returnList
                
                encoded = json.dumps(entryResult, indent=3)
                self.response.headers['Content-Type'] = 'application/json'
                self.response.out.write(encoded)
            else:
                self.response.out.write("missing entry 'yearMonth' variable")
        else:
            self.response.out.write("access denied")


class RobotsHandler(webapp2.RequestHandler):
    def get(self):
        txt = """# www.robotstxt.org/
User-agent: *
Disallow: /
"""
        self.response.headers['Content-Type'] = 'text/plain'
        self.response.write(txt)

app = webapp2.WSGIApplication([
    ('/robots.txt', RobotsHandler),
    ('/SETUP', HackServer),
    ('/', CrowdServer),
    webapp2.Route('/fetch', DLCrowd, schemes=ALLOWED_SCHEMES),
    ('/(.*)/(.*)', CrowdServer),
    ('/(.*)', CrowdServer)
    ], debug=True)

