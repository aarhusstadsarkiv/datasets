# -*- coding: UTF-8 -*-
import codecs

###############
### HELPERS ###
###############
def mapTemplateToPage(page, htmlPlaceholder, htmlBody):
    return page.replace(htmlPlaceholder, htmlBody)

def templateSelector(booleanStatement, trueCase, falseCase):
    if booleanStatement:
        return trueCase
    else:
        return falseCase
    
def templateListFactory(start, end, patteren, dataList, DSFLAG=True, *args):
    head = start
    body = u""#.replace()
    
    if dataList:
        for item in dataList:
            string = patteren
            
            i = -1
            for arg in args:
                i = i + 1
                string = string.replace(u"{" + str(i) + "}", unicode(getattr(item,arg)))
            
            body = body + string
        
        tail = end
    
    return head + body + tail

def webtemplate(template):
    ### Html template loaded 
    htmlpage = template + '.html'
    webpage = codecs.open(htmlpage, encoding="utf-8")
    template = webpage.read()
    
    return template

def updateTopNav(page, accessLevel):
    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlPlaceholder = u"<!-- TopNav -->"
    
    noAccess = u"""
    <!-- Navigation  -->
    <div id="nav-wrapper">
        <nav>        
            <ul>
              <li id="logo"><a href="/">AARHUS BYRÅDS FORHANDLINGER</a></li>
            </ul>
            <ul class="right">
              <li><a href="/top20">Top 20</a>
              <li><a href="/tutorial">Vejledning</a></li>
              <li><a href="/login">Log ind</a></li>
            </ul>
        </nav>  
    </div>
    """
    access = u"""
    <!-- Navigation  -->
    <div id="nav-wrapper">
        <nav>        
            <ul>
              <li id="logo"><a href="/">AARHUS BYRÅDS FORHANDLINGER</a></li>
            </ul>
            <ul class="right">
              <li><a href="/">Min side</a></li>
              <li><a href="/top20">Top 20</a>
              <li><a href="/tutorial">Vejledning</a></li>
              <li><a href="/logout">Log af</a></li>
            </ul>
        </nav>  
    </div>
    """
    
    htmlBody = templateSelector(accessLevel > 0, access, noAccess)
    
    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)
    
def updateMetaHeader(page):    
    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlPlaceholder = u"<!-- MetaHeader -->"
    
    ### Fjernet fra htmlBody
    ### PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"
    htmlBody = u"""
        <!DOCTYPE html>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <link rel="stylesheet" href="../css/normalize.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../css/jquery-te-1.3.5.css">
        <link rel="stylesheet" href="../css/main.css">
        
        <!-- <script type="text/javascript" src="../js/modernizr-2.6.2.min.js" charset="utf-8"></script> -->        
        <script type="text/javascript" src="../js/compatibility.js" charset="utf-8"></script>
        <script type="text/javascript" src="../js/jQuery2.0.0.min.js" charset="utf-8"></script>
        <script type="text/javascript" src="../js/jquery-te-1.3.5.js" charset="utf-8"></script>
        <script type="text/javascript" src="../js/rangy-core.js" charset="utf-8"></script>
        <script type="text/javascript" src="../js/rangy-cssclassapplier.js" charset="utf-8"></script>
        <script type="text/javascript" src="../js/rangy-selectionsaverestore.js" charset="utf-8"></script>
        <script type="text/javascript" src="../js/rangy-serializer.js" charset="utf-8"></script>
        <script type="text/javascript" src="../js/crowd.js" charset="utf-8"></script>
        <script type="text/javascript" src="../js/dragscrollable.js" charset="utf-8"></script>
        <script type="text/javascript" src="../js/scrollsync.js" charset="utf-8"></script>
    """
    
    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)

###############
##### Login ###
###############

def updateLogin(page):
    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlPlaceholder = u"<!-- Login -->"
    
    htmlBody = u"""
    <div>
        <h2>Login</h2>
        <form method='POST' enctype='application/x-www-form-urlencoded' action='/login'>
            <section class="input-text">
                <section class="input-text-label">E-mail:</section>
                <section class="input-text-field">
                    <input class="defaultDigitInput" type="text" id="email" name="email">
                </section>
            </section>
            <section class="input-text">
                <section class="input-help"></section>
                <section class="input-text-label">Kodeord:</section>
                <section class="input-text-field"><input class="defaultDigitInput" type="password" id="password" name="password"></section>
            </section>
            <!-- <li><section class="text_field"><a href="forgottenEmail">Glemt dit kodeord? Tryk her</a></section></li> -->
            <section class="form-footer-short">
                <input class="btn" type="submit" id="fetch" value="Login">
            </section>
        </form>
    </div>
    """
    
    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)

def updateFooter(page):
    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlPlaceholder = u"<!-- Footer -->"
    
    htmlBody = u"""
    <footer>
        <ul>
            <li>Aarhus Stadsarkiv</li>
            <li>Vester Allé 12, 8000 Aarhus C</li>
            <li>Tlf.: 89404800</li>
            <li><a href="http://aarhusstadsarkiv.dk">Hjemmeside</a></li>
            <li><a href="mailto:stadsarkiv@aarhus.dk">Kontakt os</a></li>
            <li><a href="https://www.facebook.com/pages/Aarhus-Stadsarkiv/237755849655105">Facebook side</a></li>
        </ul>
    </footer> <!-- End of footer -->
    """
    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)
    
#def updateIndex(page):
#    ### Placeholder is the tag to find and replace in the page template
#    ### Body is the html container to inject into the placeholder position in the page template
#    htmlPlaceholder = u"<!-- Index Header -->"
#    
#    htmlBody = u"""
#    <h2>Velkommen</h2>
#    """
#    ### Dont touch! Returned information for the web server :D
#    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)

def updateTop20(page, top20List):    
    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlPlaceholder = u"<!-- Top 20 -->"
    
    htmlBody = templateListFactory(u"<ol>", u"</ol>", "<li>{0} - {1}</li>", top20List, True, "name", "antal")
    
    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)

def updateTextField(page, text, className="alert"):
    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlPlaceholder = u"<!-- Optional Text -->"
    
    htmlBody = u"""<p class="{0}">{1}</p>""".format(className, text)
    
    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)

def updateMinSideRecords(page, recordList):
    def commaStringToArray(commaString):
        if commaString:
            if commaString != "":
                array = commaString.split(",")
            else:
                array = []
                
            return array
        else:
            return []

    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlPlaceholder = u"<!-- Current Records -->"

    recordsLocked = len(recordList)
    recordButton = u"""<li style="padding-top:4px;"><a href="getNewRecord">Hent et nyt møde </a>""" + str(recordsLocked) + u""" / 5 åbne møder.</li>"""

    newRecordButton = templateSelector(recordsLocked < 5, recordButton, "")

    listEntry = u""""""
    if recordList:
        for entity in recordList:
            untouchedRecords = commaStringToArray(entity.untouchedRecords)
            doneRecords = commaStringToArray(entity.doneRecords)
            length = len(untouchedRecords) + len(doneRecords)

            if entity.status == "delayed":
                classVar = "delayed"
            else:
                classVar = "locked"
       
            if len(untouchedRecords) != 0:
                pageNr = untouchedRecords[0]
                pageCount = u"side: {0}/{1}".format(pageNr, length)
                element = u"""<li class = {0}>{1} {2}<a style="float: right; margin-right:2px;" href="markRecord/{1}-{3}">Genoptag</a></li>
                """.format(classVar, entity.collectionID, pageCount, pageNr)
            else:
                pageCount = u"side: {0}/{0}".format(length)
                element = u"""<li style="border: 2px solid;">{0} {1}</li>
                """.format(entity.collectionID, pageCount)

            listEntry = listEntry + element

    htmlBody = u"""
    <div class="recordCollectionList">
        <ul style="list-style: none; padding-left: 5px; padding-right: 5px; margin-top: 5px;">
            """ + listEntry + u"""
            <li>""" + newRecordButton + u"""</li>
        </ul>
    </div>
    """

    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)

def updateMinSideUserInfo(page, user):
    ### Placeholder is the tag to find and replace in the page template
    ### Body is the html container to inject into the placeholder position in the page template
    htmlPlaceholder = u"<!-- User Infomation -->"
    
    htmlBody = u"""
    <div class="stats">
        Antal sider anmærket: <br />
        {0}
    </div>
    <div class="brugerInfo">
        <ul style="list-style: none; padding-left: 5px;">
            <li>Navn: {1}</li>
            <li>Email: {2}</li>
            <li>Kodeord: {3}</li>
        </ul>
    </div>
    """.format(user.antal, user.name, user.email, user.password)
    
    ### Dont touch! Returned information for the web server :D
    return mapTemplateToPage(page, htmlPlaceholder, htmlBody)